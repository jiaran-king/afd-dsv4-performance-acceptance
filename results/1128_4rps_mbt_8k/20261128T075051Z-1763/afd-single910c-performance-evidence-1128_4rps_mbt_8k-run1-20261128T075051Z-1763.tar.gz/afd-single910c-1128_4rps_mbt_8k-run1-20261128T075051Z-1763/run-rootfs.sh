#!/usr/bin/env bash
set -euo pipefail

target=${1:?}
image_store=${2:?}
image=${3:?}
shift 3
export PATH="$image_store/docker:$PATH"
export DOCKER_HOST="unix://$target/docker.sock" DOCKER_CONFIG="$target/client"

name="afd-acceptance-$(basename "$target")-$$"
docker run -d --name "$name" --entrypoint /bin/sleep "$image" 86400 >/dev/null
mounts=()
finish() {
    local status=$? index
    trap - EXIT
    for ((index=${#mounts[@]} - 1; index >= 0; index--)); do
        if ! umount -R "${mounts[index]}"; then status=1; fi
    done
    if ! docker rm -f "$name" >/dev/null; then status=1; fi
    exit "$status"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

root=$(docker inspect --format '{{.GraphDriver.Data.MergedDir}}' "$name")
case "$root" in
    "$image_store"/docker-data/overlay2/*/merged) ;;
    *) printf 'Unexpected Docker root: %s\n' "$root" >&2; exit 2 ;;
esac
test -r "$root/etc/os-release"

bind() {
    local source=$1 destination=$2 mode=$3
    local full="$root$destination"
    case "$(realpath -m -- "$full")" in
        "$root"/*) ;;
        *) printf 'Mount point escapes the image: %s\n' "$destination" >&2; return 2 ;;
    esac
    if [[ -d "$source" ]]; then
        mkdir -p "$full"
    else
        mkdir -p "$(dirname -- "$full")"
        if [[ ! -e "$full" ]]; then touch "$full"; fi
    fi
    if [[ "$mode" == recursive ]]; then
        mount --rbind "$source" "$full"
        mounts+=("$full")
        mount --make-rprivate "$full"
    else
        mount --bind "$source" "$full"
        mounts+=("$full")
        mount --make-private "$full"
        if [[ "$mode" == ro ]]; then mount -o remount,bind,ro "$full"; fi
    fi
}

bind /dev /dev recursive
bind /sys /sys ro
bind /proc /proc ro
bind /usr/local/Ascend/driver /usr/local/Ascend/driver ro
for driver_part in include lib64; do
    driver_path="/usr/local/Ascend/driver/$driver_part"
    if [[ -d "$driver_path" ]]; then bind "$driver_path" "$driver_path" ro; fi
done
bind "$(readlink -f "$(command -v npu-smi)")" /usr/local/bin/npu-smi ro
bind "$(readlink -f /home/admin/model)" /home/admin/model ro
bind "$target/repo" /work/acceptance rw
for candidate in /etc/resolv.conf /etc/hosts /etc/ascend_install.info /usr/local/Ascend/add-ons /usr/local/dcmi; do
    if [[ -e "$candidate" && ! -L "$root$candidate" ]]; then bind "$candidate" "$candidate" ro; fi
done

mapfile -t image_env < <(docker image inspect --format '{{range .Config.Env}}{{println .}}{{end}}' "$image")
image_user_home=$(docker exec "$name" /usr/bin/printenv HOME)
values=("HOME=$image_user_home")
for item in "${image_env[@]}"; do
    if [[ "$item" == *=* ]]; then values+=("$item"); fi
done
for variable in ASCEND_VISIBLE_DEVICES ASCEND_DOCKER_RUNTIME ASCEND_RUNTIME_OPTIONS; do
    if [[ -n ${!variable-} ]]; then values+=("$variable=${!variable}"); fi
done
chroot "$root" /usr/bin/env -i "${values[@]}" "$@"
