#!/usr/bin/env bash
set -euo pipefail
cd /work/acceptance
(
    set +u
    source /usr/local/Ascend/cann/set_env.sh
    set -u
    python3 - <<'PY'
import torch
import torch_npu
import vllm
import vllm_ascend

print(f"vLLM: {vllm.__file__}", flush=True)
print(f"vLLM-Ascend: {vllm_ascend.__file__}", flush=True)
assert torch.npu.device_count() == 16
print("16 logical DIEs visible", flush=True)
values = (torch.ones(2, device="npu:0") + 1).cpu().tolist()
assert values == [2.0, 2.0], values
print(f"Tensor probe: {values}", flush=True)
PY
) 2>&1 | tee .runtime/image-npu-probe.log

console=".runtime/acceptance-console-$(date -u +%Y%m%dT%H%M%SZ).log"
trap 'printf "%s\n" "$?" > .runtime/reproduce.exit' EXIT
./reproduce.sh --site site.env 2>&1 | tee "$console"
