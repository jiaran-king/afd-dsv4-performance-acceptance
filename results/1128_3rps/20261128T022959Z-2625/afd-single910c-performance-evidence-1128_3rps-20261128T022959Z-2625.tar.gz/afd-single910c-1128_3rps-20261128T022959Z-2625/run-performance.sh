#!/usr/bin/env bash
set -euo pipefail
umask 022

target=$(cd -- "$(dirname -- "$0")" && pwd -P)
previous=${1:?Provide the verified existing image store}
docker_pid=
finish() {
    local status=$?
    trap - EXIT
    if [[ -n "$docker_pid" ]] && kill -0 "$docker_pid" 2>/dev/null; then
        kill -TERM "$docker_pid" || status=1
        wait "$docker_pid" || status=1
    fi
    printf '%s\n' "$status" > "$target/controller.exit.pending"
    mv -- "$target/controller.exit.pending" "$target/controller.exit"
    printf 'Controller exited with %s at %s\n' "$status" "$(date -u +%FT%TZ)"
    exit "$status"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
printf '%s\n' "$$" > "$target/controller.pid"

repo="$target/repo"
base_commit=4922a133f55e86594f864e5400923c71b0db332e
commit=ac3c21df9ce0026e000b05be57e966ee7dafc68e
test "$(git -C "$repo" rev-parse HEAD)" = "$commit"
test "$(git -C "$repo" rev-parse HEAD^)" = "$base_commit"
test -z "$(git -C "$repo" status --porcelain --untracked-files=no)"
printf 'v0.3.0 %s\n1128_3rps %s\n' "$base_commit" "$commit" > "$target/acceptance-source.txt"
git -C "$repo" diff --binary "$base_commit" "$commit" > "$target/1128_3rps-rate.patch"

{
    printf 'Captured at %s\n' "$(date -u +%FT%TZ)"
    uname -m
    printf 'Visible CPUs: %s\n' "$(nproc)"
    grep -E '^(Cpus_allowed_list|Mems_allowed_list):' /proc/self/status
    for path in /sys/fs/cgroup/{cpu.max,memory.max,cpuset.cpus.effective,cpu/cpu.cfs_quota_us,cpu/cpu.cfs_period_us,memory/memory.limit_in_bytes}; do
        if [[ -r "$path" ]]; then printf '%s: ' "$path"; cat "$path"; fi
    done
    df -h /dev/shm "$target"
    head -n 2 /usr/local/Ascend/driver/version.info
    npu-smi info -m
    npu-smi info
} > "$target/node-resources.txt"

printf 'Checking the mounted model and workload\n'
cd /home/admin/model
sha256sum -c <<'HASH' | tee "$target/model-metadata-check.txt"
6c6cdc4a47e00e41137081429b95bd5c1cf91ba62e87309d1398431de7f4a8e1  config.json
a2e85871ba049d8b475bb5de5b75a79b6fedb577eefc2ae86d57879143431b60  quant_model_description.json
8f9f37ca37fdc4f5fd36d5cf4d3b0e8392edb4e894fd10cc0d70b4957c8633cf  tokenizer.json
HASH

runtime="$repo/.runtime"
mkdir -p "$runtime/downloads"
archive=afd-wildchat-rps4-v2.tar.gz
cp -- "$previous/repo/.runtime/downloads/$archive" "$runtime/downloads/$archive"
(cd "$runtime/downloads" && printf '%s  %s\n' 0f0e38743b2cdced2a376b2f6a3801bc5254e48132f04d52ccc5b745e3e386f8 "$archive" | sha256sum -c) \
    | tee "$target/workload-check.txt"

pinned_afd=98f45bbff76bb5165789313c1076fea5c92d8c44
cached="$previous/repo/.runtime"
if [[ "$(git -C "$cached/afd-plugin" rev-parse --verify HEAD)" == "$pinned_afd" ]]; then
    git clone -q --no-hardlinks "$cached/afd-plugin" "$runtime/afd-plugin"
fi
cd "$cached/afd-install"
if sha256sum -c <<'HASH' | tee "$target/cached-native-check.txt"
616b708af270882cac283e7e3c26b423c09189619ffd1026bb115e93cae51ea8  afd_plugin/compat/npu/feature_validation.py
16b30c75b7671668ed2804ad1b067da5e5fa93d8678360c4e7dea047813816c1  afd_plugin/_cann_ops_custom/vendors/afd-plugin/op_api/lib/libcust_opapi.so
93e04c00a1323a8995573bb6188c36d2d2dbca700661aa0a346035e46a1c048f  afd_plugin/_C_ascend.cpython-312-aarch64-linux-gnu.so
HASH
then
    cp -a -- "$cached/afd-install" "$runtime/afd-install"
    find "$runtime/afd-install" -type d -name __pycache__ -prune -exec rm -r -- {} +
fi
cd "$target"

python3 - "$repo" <<'PY'
import fcntl
from pathlib import Path
import re
import socket
import struct
import subprocess
import sys

repo = Path(sys.argv[1])
routes = Path("/proc/net/route").read_text().splitlines()[1:]
interfaces = {fields[0] for line in routes if (fields := line.split())[1] == "00000000"}
interface, = interfaces
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
    data = fcntl.ioctl(sock.fileno(), 0x8915, struct.pack("256s", interface.encode()))
    ip = socket.inet_ntoa(data[20:24])

mapping = subprocess.check_output(["npu-smi", "info", "-m"], text=True)
devices = re.findall(r"^\s*\d+\s+\d+\s+(\d+)\s+\d+\s+Ascend910.*$", mapping, re.M)
if devices != [str(device) for device in range(16)]:
    raise ValueError(f"Assigned logical DIEs differ from the verified 0–15 layout: {devices}")
replacements = {
    "P_NODE_IP": ip,
    "P_NIC": interface,
    "P_DEVICES": ",".join(devices),
    "P_MODEL_DIR": "/home/admin/model",
}
template = (repo / "site.env.example").read_text()
lines = []
for line in template.splitlines():
    key = line.partition("=")[0]
    lines.append(f"{key}={replacements[key]}" if key in replacements else line)
lines.append("WORKLOAD_ARCHIVE=/work/acceptance/.runtime/downloads/afd-wildchat-rps4-v2.tar.gz")
(repo / "site.env").write_text("\n".join(lines) + "\n")
print(f"Configured {len(devices)} logical DIEs on {interface}")
PY

export PATH="$previous/docker:$PATH" DOCKER_HOST="unix://$target/docker.sock" DOCKER_CONFIG="$target/client"
mkdir -p "$DOCKER_CONFIG"
printf '{}\n' > "$target/daemon.json"
dockerd --config-file "$target/daemon.json" --host "$DOCKER_HOST" \
    --data-root "$previous/docker-data" --exec-root "$target/docker-exec" \
    --pidfile "$target/docker.pid" --storage-driver overlay2 \
    --bridge none --iptables=false --ip6tables=false --ip-forward=false --ip-masq=false \
    --userland-proxy=false > "$target/dockerd.log" 2>&1 < /dev/null &
docker_pid=$!

docker_ready() {
    local try
    for try in {1..40}; do
        if docker info --format '{{.ServerVersion}} {{.Driver}} {{.CgroupVersion}}' 2>/dev/null; then return 0; fi
        if ! kill -0 "$docker_pid" 2>/dev/null; then break; fi
        sleep 1
    done
    tail -60 "$target/dockerd.log"
    return 1
}
docker_ready | tee "$target/docker-version.txt"

base=quay.io/ascend/vllm-ascend:v0.30.0-a3-openeuler
base_digest=sha256:0b8bf5b484d49c667ceab717347eb3a8695388429aebd9084b79fa0f57a545c0
expected_image=sha256:1b895806dfdcc1ea38363ff23ae4912ad63e3764f8dc6f3f685059e49fa99014
image=afd-910c-acceptance:single-rc2
docker image inspect --format '{{.Id}} {{.Architecture}} {{json .RepoDigests}}' "$base@$base_digest" | tee "$target/base-image.txt"
grep -Fq "$base_digest" "$target/base-image.txt"
docker image inspect --format '{{.Id}} {{.Architecture}}' "$image" | tee "$target/derived-image.txt"
test "$(cat "$target/derived-image.txt")" = "$expected_image arm64"

cp -- "$target/run-in-image.sh" "$runtime/run-in-image.sh"
printf 'Starting the v0.3.0 entrypoint at %s\n' "$(date -u +%FT%TZ)"
bash "$target/run-rootfs.sh" "$target" "$previous" "$expected_image" \
    /bin/bash /work/acceptance/.runtime/run-in-image.sh
