#!/usr/bin/env bash
set -euo pipefail
cd /work/acceptance
(
    set +u
    source /usr/local/Ascend/cann/set_env.sh
    set -u
    python3 - <<'PY'
import torch
import torch_npu
import vllm
import vllm_ascend

print(f"vLLM: {vllm.__file__}", flush=True)
print(f"vLLM-Ascend: {vllm_ascend.__file__}", flush=True)
assert torch.npu.device_count() == 16
print("16 logical DIEs visible", flush=True)
values = (torch.ones(2, device="npu:0") + 1).cpu().tolist()
assert values == [2.0, 2.0], values
print(f"Tensor probe: {values}", flush=True)
PY
) 2>&1 | tee .runtime/image-npu-probe.log


label=1128_3rps_mbt_8k
overall=0
trap 'printf "%s\n" "$?" > .runtime/reproduce.exit' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

for trial in 1 2; do
    console=".runtime/acceptance-console-$label-trial-$trial-$(date -u +%Y%m%dT%H%M%SZ).log"
    printf 'Starting trial %s/2 at %s\n' "$trial" "$(date -u +%FT%TZ)"
    set +e
    ./reproduce.sh --site site.env 2>&1 | tee "$console"
    pipeline_status=("${PIPESTATUS[@]}")
    set -e
    status=${pipeline_status[0]}
    printf '%s\n' "$status" > ".runtime/reproduce-trial-$trial.exit"
    if (( pipeline_status[1] != 0 )); then exit 1; fi
    run_id=$(sed -n 's|^Artifacts are in /work/acceptance/runs/||p' "$console" | head -n 1)
    if [[ ! "$run_id" =~ ^[0-9]{8}T[0-9]{6}Z-[0-9]+$ ]]; then
        printf 'Trial %s did not record a run ID. See %s\n' "$trial" "$console" >&2
        exit 1
    fi
    printf '%s\t%s\t%s\t%s\n' "$trial" "$run_id" "$status" "$console" > ".runtime/trial-$trial.tsv"
    npu-smi info > ".runtime/node-post-run-trial-$trial.txt"
    printf 'Trial %s ended with %s. Run ID %s\n' "$trial" "$status" "$run_id"
    if [[ ! -s "runs/$run_id/acceptance.json" || -e runs/.active ]]; then
        printf 'Trial %s did not finish the full acceptance flow. See %s\n' "$trial" "$console" >&2
        exit 1
    fi
    if (( status != 0 )); then overall=1; fi
done
exit "$overall"
